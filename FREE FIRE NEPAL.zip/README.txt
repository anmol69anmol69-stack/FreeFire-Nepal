FREE FIRE NEPAL — Home screen app

To get FREE FIRE NEPAL on your Android home screen:
1. Extract this ZIP file.
2. Upload the extracted files to a secure HTTPS static host (for example, GitHub Pages).
3. Open the published website in Chrome on your phone.
4. Tap Chrome ⋮ > Add to Home screen (or Install app).
5. Confirm the name FREE FIRE NEPAL.

A downloaded HTML/ZIP file cannot automatically place an icon on your home screen. Android requires you to approve the shortcut/install, and installable PWA apps must be served from HTTPS.
